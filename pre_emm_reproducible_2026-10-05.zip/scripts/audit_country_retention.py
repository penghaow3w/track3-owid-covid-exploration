"""Audit country retention and descriptor coverage before EMM."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'data/processed/pre_emm_2026-10-05'
DESCRIPTORS = ['population','median_age','life_expectancy','population_density','gdp_per_capita']

def audit():
    started = datetime.now(ZoneInfo('Europe/Berlin')).isoformat()
    w = pd.read_csv(OUT/'validated_country_week.csv')
    country = w.groupby('country').agg(continent=('continent','first'),candidate_weeks=('complete','size'),
        complete_weeks=('complete','sum'),positive_weeks=('positive','sum'))
    country['complete_retention_pct'] = 100*country.complete_weeks/country.candidate_weeks
    country['positive_retention_pct'] = 100*country.positive_weeks/country.candidate_weeks
    country['zero_complete_weeks'] = country.complete_weeks-country.positive_weeks
    country.sort_values(['complete_retention_pct','country']).to_csv(OUT/'country_retention.csv')
    usable = w.loc[w.positive].copy()
    rows=[]
    missing=[]
    for c in DESCRIPTORS:
        flag=usable[c].isna()
        by_country=usable.groupby('country')[c].agg(['count','size','nunique'])
        rows.append({'descriptor':c,'eligible_positive_weeks':len(usable),'missing_weeks':int(flag.sum()),
            'missing_week_pct':100*flag.mean(),'locations_with_any_missing':int(usable.loc[flag,'country'].nunique()),
            'locations_entirely_missing':int(by_country['count'].eq(0).sum()),
            'locations_with_multiple_observed_values':int(by_country['nunique'].gt(1).sum())})
        for name, g in usable.loc[flag].groupby('country'):
            missing.append({'descriptor':c,'country':name,'missing_positive_weeks':len(g)})
    pd.DataFrame(rows).to_csv(OUT/'descriptor_coverage_audit.csv',index=False)
    pd.DataFrame(missing).to_csv(OUT/'descriptor_missing_locations.csv',index=False)
    core=DESCRIPTORS[:4]
    core_ok=usable[core].notna().all(axis=1)
    gdp_ok=usable[DESCRIPTORS].notna().all(axis=1)
    coverage=pd.DataFrame([
        {'analysis':'target_only','weeks':len(usable),'locations':usable.country.nunique()},
        {'analysis':'core_descriptors_complete','weeks':int(core_ok.sum()),'locations':usable.loc[core_ok,'country'].nunique()},
        {'analysis':'core_plus_GDP_complete','weeks':int(gdp_ok.sum()),'locations':usable.loc[gdp_ok,'country'].nunique()},
    ])
    coverage.to_csv(OUT/'analysis_population_coverage.csv',index=False)
    continent=w.groupby('continent').agg(candidate_weeks=('complete','size'),complete_weeks=('complete','sum'),positive_weeks=('positive','sum'),locations=('country','nunique'))
    continent['complete_retention_pct']=100*continent.complete_weeks/continent.candidate_weeks
    continent.to_csv(OUT/'continent_retention.csv')
    meta={'started_at':started,'finished_at':datetime.now(ZoneInfo('Europe/Berlin')).isoformat(),
          'candidate_locations':int(country.shape[0]),'positive_locations':int(usable.country.nunique()),
          'no_positive_locations':country.index[country.positive_weeks.eq(0)].tolist(),
          'interpretation':'Positive retention includes true zero weeks; it is not a missingness rate. Candidate weeks cover observed country intervals, not all pandemic weeks. Core complete cases are a sensitivity cohort, not an automatic mandatory exclusion.'}
    (OUT/'country_audit_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(meta,indent=2))
    print(coverage.to_string(index=False))
    return country,pd.DataFrame(rows),coverage,continent

if __name__=='__main__':
    audit()
