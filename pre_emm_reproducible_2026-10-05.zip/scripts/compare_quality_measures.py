"""Compare three distances on fixed cohorts and predeclared subgroups."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json
import numpy as np
import pandas as pd
from scripts.run_pre_emm_experiment import distribution, tv_distance

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data/processed/pre_emm_2026-10-05'

def distances(p,q):
    p,q=p.to_numpy(),q.to_numpy()
    m=(p+q)/2
    def kl(a):
        positive=a>0
        return float(np.sum(a[positive]*np.log2(a[positive]/m[positive])))
    return {'TV':float(.5*np.abs(p-q).sum()),
            'JS_divergence_bits':.5*(kl(p)+kl(q)),
            'Hellinger':float(np.sqrt(.5*np.sum((np.sqrt(p)-np.sqrt(q))**2)))}

def compare():
    started=datetime.now(ZoneInfo('Europe/Berlin')).isoformat()
    rows=[]
    for k,field in [(1,'first_digit'),(2,'first_2_digits')]:
        d=pd.read_csv(OUT/f'cohort_k{k}_core_complete.csv',dtype={field:'string'})
        cuts=d.groupby('country').population_density.first().quantile([.25,.75])
        masks={'continent=Europe':d.continent.eq('Europe'),'continent=Asia':d.continent.eq('Asia'),
            'year=2020':d.year.eq(2020),'year=2021':d.year.eq(2021),
            'population_density<=Q1':d.population_density.le(cuts.loc[.25]),
            'population_density>=Q3':d.population_density.ge(cuts.loc[.75])}
        for name,mask in masks.items():
            p=distribution(d.loc[mask,field],k)
            q=distribution(d.loc[~mask,field],k)
            scores=distances(p,q)
            assert all(0<=v<=1+1e-12 for v in scores.values())
            rows.append({'K':k,'subgroup':name,'cohort_rows':len(d),'subgroup_n':int(mask.sum()),
                'complement_n':int((~mask).sum()),'support':float(mask.mean()),**scores})
    result=pd.DataFrame(rows)
    measures=['TV','JS_divergence_bits','Hellinger']
    for c in measures:
        result[c+'_rank']=result.groupby('K')[c].rank(method='min',ascending=False).astype(int)
    result.to_csv(OUT/'quality_measure_comparison.csv',index=False)
    check=pd.Series([1.,0.]); opposite=pd.Series([0.,1.])
    assert all(abs(v)<1e-12 for v in distances(check,check).values())
    assert all(abs(v-1)<1e-12 for v in distances(check,opposite).values())
    meta={'started_at':started,'finished_at':datetime.now(ZoneInfo('Europe/Berlin')).isoformat(),
        'comparison':'same core-complete cohort within each K; subgroup vs complement',
        'JS_log_base':2,'Hellinger_normalization':'sqrt(0.5 * sum((sqrt(p)-sqrt(q))^2))',
        'search':'six manually specified rules; no automatic EMM search',
        'interpretation':'Distances are candidate ranking scores, not p-values. Scores across metrics or K are not directly comparable. No support penalty.'}
    (OUT/'quality_comparison_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(meta,indent=2))
    return result

if __name__=='__main__': compare()
