"""Pre-EMM experiment: subgroup vs complement leading-digit distributions.

This script deliberately does not run EMM. It tests the proposed model class
and candidate TV quality measure on a small, explicit set of subgroups.
"""
from pathlib import Path
import json
from datetime import datetime
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/processed/pre_emm_2026-10-05/validated_country_week.csv"
OUT = ROOT / "data/processed/pre_emm_2026-10-05"
OUT.mkdir(parents=True, exist_ok=True)

TARGET = "first_digit"
DIGITS = [str(d) for d in range(1, 10)]


def distribution(values: pd.Series, k: int = 1) -> pd.Series:
    """Return a normalized leading-digit distribution with fixed digit support."""
    if not isinstance(k, int) or k < 1:
        raise ValueError('K must be a positive integer')
    values = values.dropna().astype(str)
    values = values[values.str.len().ge(k)]
    if not values.str.fullmatch(r'[1-9][0-9]*').all():
        raise ValueError('Expected positive digit strings')
    counts = values.str[:k].value_counts().reindex(
        [str(i) for i in range(10**(k-1), 10**k)], fill_value=0
    )
    total = counts.sum()
    if not total:
        raise ValueError('No eligible observations for this K')
    return counts.astype(float) / total


def tv_distance(p: pd.Series, q: pd.Series) -> float:
    """Total variation distance between two aligned empirical distributions."""
    return float(0.5 * np.abs(p - q).sum())


def score_subgroup(frame: pd.DataFrame, name: str, mask: pd.Series, k: int = 1) -> dict:
    target = "first_digit" if k == 1 else "first_2_digits"
    eligible = frame[target].notna()
    if name.startswith("population_density"):
        eligible &= frame["population_density"].notna()
    subgroup = frame.loc[eligible & mask, target]
    complement = frame.loc[eligible & ~mask, target]
    p = distribution(subgroup, k)
    q = distribution(complement, k)
    return {
        "subgroup": name,
        "K": k,
        "total_rows": int(eligible.sum()),
        "excluded_rows": int((~eligible).sum()),
        "subgroup_rows": int((eligible & mask).sum()),
        "subgroup_digit_rows": int(subgroup.notna().sum()),
        "complement_digit_rows": int(complement.notna().sum()),
        "support_fraction": round(float((eligible & mask).sum()/eligible.sum()), 6),
        "TV_distance": round(tv_distance(p, q), 8),
    }


def main() -> None:
    frame = pd.read_csv(INPUT, low_memory=False, dtype={'first_digit':'string','first_2_digits':'string','first_3_digits':'string'})
    frame["week_start"] = pd.to_datetime(frame["week_start"], errors="coerce")
    frame["year"] = frame["year"].astype("Int64")

    # The formal experiment uses positive complete weeks only. Missing target
    # values never become zero and are not silently imputed.
    analysis = frame.loc[frame[TARGET].notna()].copy()
    analysis["population_density"] = pd.to_numeric(analysis["population_density"], errors="coerce")
    density_thresholds = analysis.groupby("country")["population_density"].first().dropna().quantile([0.25, 0.75])

    masks = {
        "continent=Europe": analysis["continent"].eq("Europe"),
        "continent=Asia": analysis["continent"].eq("Asia"),
        "year=2020": analysis["year"].eq(2020),
        "year=2021": analysis["year"].eq(2021),
        "population_density<=Q1": analysis["population_density"].le(density_thresholds.loc[0.25]),
        "population_density>=Q3": analysis["population_density"].ge(density_thresholds.loc[0.75]),
    }

    rows = []
    for k in (1, 2):
        target = "first_digit" if k == 1 else "first_2_digits"
        for name, mask in masks.items():
            rows.append(score_subgroup(analysis, name, mask.fillna(False), k=k))

    result = pd.DataFrame(rows).sort_values(["K", "TV_distance"], ascending=[True, False])
    result.to_csv(OUT / "manual_subgroup_tv_scores.csv", index=False)

    metadata = {
        "created_at": datetime.now(ZoneInfo("Europe/Amsterdam")).isoformat(),
        "input": str(INPUT),
        "rows_in_input": int(len(frame)),
        "rows_in_formal_analysis": int(len(analysis)),
        "target": "weekly_new_cases",
        "model_class": "empirical first-K-leading-digit distribution",
        "quality_measure": "TV(P_subgroup, Q_complement)",
        "imputation": "none; missing target values excluded from formal digit analysis",
        "subgroups": list(masks),
        "density_thresholds": {str(k): float(v) for k, v in density_thresholds.items()},
        "emm_run": False,
    }
    (OUT / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(result.to_string(index=False))
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
