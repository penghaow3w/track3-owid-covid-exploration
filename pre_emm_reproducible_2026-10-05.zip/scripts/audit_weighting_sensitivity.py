"""Descriptive sensitivity to unequal country contribution and year coverage."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json
import pandas as pd
from scripts.run_pre_emm_experiment import distribution
from scripts.compare_quality_measures import distances

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data/processed/pre_emm_2026-10-05'

def country_equal_distribution(d,field,k):
    # Normalize within each country, then average countries equally within group.
    probabilities=[distribution(g[field],k) for _,g in d.groupby('country')]
    if not probabilities: raise ValueError('Empty group')
    return pd.concat(probabilities,axis=1).mean(axis=1)

def audit_sensitivity():
    started=datetime.now(ZoneInfo('Europe/Berlin')).isoformat()
    scores=[]; coverage=[]
    for k,field in [(1,'first_digit'),(2,'first_2_digits')]:
        d=pd.read_csv(OUT/f'cohort_k{k}_core_binned.csv',dtype={field:'string'},parse_dates=['week_start','week_end'])
        for year,g in d.groupby('year'):
            coverage.append({'K':k,'year':int(year),'weeks':len(g),'locations':g.country.nunique(),
                'first_week_start':g.week_start.min(),'last_week_end':g.week_end.max(),
                'median_weeks_per_location':g.groupby('country').size().median(),
                'max_country_share':g.groupby('country').size().max()/len(g)})
        rules={f'continent={v}':d.continent.eq(v) for v in sorted(d.continent.unique())}
        rules.update({f'year={v}':d.year.eq(v) for v in sorted(d.year.unique())})
        for c in ['population','median_age','life_expectancy','population_density']:
            rules.update({f'{c}:{v}':d[c+'_bin'].eq(v) for v in ['Q1','Q2','Q3','Q4']})
        for name,mask in rules.items():
            for weighting in ('week_equal','country_equal'):
                group=d.loc[mask]; complement=d.loc[~mask]
                if weighting=='week_equal':
                    p,q=distribution(group[field],k),distribution(complement[field],k)
                else:
                    p,q=country_equal_distribution(group,field,k),country_equal_distribution(complement,field,k)
                scores.append({'K':k,'rule':name,'weighting':weighting,
                    'subgroup_locations':group.country.nunique(),'complement_locations':complement.country.nunique(),**distances(p,q)})
    result=pd.DataFrame(scores)
    for measure in ['TV','JS_divergence_bits','Hellinger']:
        result[measure+'_rank']=result.groupby(['K','weighting'])[measure].rank(method='min',ascending=False).astype(int)
    result.to_csv(OUT/'country_weighting_scores.csv',index=False)
    years=pd.DataFrame(coverage)
    years.to_csv(OUT/'year_coverage_audit.csv',index=False)
    # Removing year=2026 from the ranking is only a candidate-rule check, not
    # a rerun on a restricted dataset. Record that distinction explicitly.
    no_latest=result.loc[~result.rule.eq('year=2026')].copy()
    no_latest['TV_rank_without_2026_rule']=no_latest.groupby(['K','weighting']).TV.rank(method='min',ascending=False).astype(int)
    no_latest.to_csv(OUT/'ranking_without_2026_rule.csv',index=False)
    meta={'started_at':started,'finished_at':datetime.now(ZoneInfo('Europe/Berlin')).isoformat(),
        'country_equal_definition':'Each country gets equal weight separately inside subgroup and complement after its digit distribution is normalized.',
        'interpretation':'Different estimand from equal-week distribution; comparison is descriptive, not significance testing.',
        'latest_year_check':'Coverage table plus removing 2026 candidate rule; latter does not remove 2026 records from other groups.',
        'remaining':'A common reporting window and dependence-aware uncertainty remain research design choices.'}
    (OUT/'weighting_sensitivity_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(meta,indent=2))
    return result,years

if __name__=='__main__': audit_sensitivity()
