"""Rebuild weekly targets with explicit daily-value eligibility checks."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / 'data/raw/compact_2026-10-04.csv'
OUT = ROOT / 'data/processed/pre_emm_2026-10-05'

def build():
    OUT.mkdir(parents=True, exist_ok=True)
    started = datetime.now(ZoneInfo('Europe/Berlin')).isoformat()
    checksum = hashlib.sha256(RAW.read_bytes()).hexdigest()
    raw = pd.read_csv(RAW, parse_dates=['date'], low_memory=False)
    review = raw.loc[raw.continent.isna()]
    d = raw.loc[raw.continent.notna()].copy()
    assert not d.duplicated(['country','date']).any(), 'Duplicate country-date keys'
    d['week_start'] = d.date - pd.to_timedelta(d.date.dt.weekday, unit='D')
    x = pd.to_numeric(d.new_cases, errors='coerce')
    d['new_cases'] = x
    d['negative'] = x.lt(0)
    d['nonfinite'] = x.notna() & ~np.isfinite(x)
    d['noninteger'] = x.notna() & np.isfinite(x) & x.ne(np.floor(x))
    descriptors = ['continent','population','population_density','median_age','life_expectancy','gdp_per_capita']
    agg = {c:(c,'first') for c in descriptors}
    agg.update(days=('date','nunique'), observed_new_cases=('new_cases','count'),
               negative_days=('negative','sum'), nonfinite_days=('nonfinite','sum'),
               noninteger_days=('noninteger','sum'), partial_sum=('new_cases','sum'))
    w = d.groupby(['country','week_start'],observed=True).agg(**agg).reset_index()
    w['week_end'] = w.week_start + pd.Timedelta(days=6)
    w['missing_calendar_days'] = 7-w.days
    w['missing_target_days'] = w.days-w.observed_new_cases
    flags = {
        'incomplete_calendar':w.days.ne(7),
        'missing_daily_target':w.missing_target_days.gt(0),
        'negative_daily_target':w.negative_days.gt(0),
        'nonfinite_daily_target':w.nonfinite_days.gt(0),
        'noninteger_daily_target':w.noninteger_days.gt(0),
    }
    w['complete'] = ~pd.DataFrame(flags).any(axis=1)
    w['exclusion_reasons'] = [';'.join(name for name, mask in flags.items() if mask.iloc[i]) for i in range(len(w))]
    w['new_cases'] = w.partial_sum.where(w.complete)
    w['positive'] = w.new_cases.gt(0)
    for k, name in [(1,'first_digit'),(2,'first_2_digits'),(3,'first_3_digits')]:
        digits = pd.Series(pd.NA,index=w.index,dtype='string')
        text = w.loc[w.positive,'new_cases'].astype('int64').astype(str)
        valid = text.str.len().ge(k)
        digits.loc[text.index[valid]] = text.loc[valid].str[:k]
        w[name] = digits
    w['year'] = w.week_start.dt.year
    w.to_csv(OUT/'validated_country_week.csv',index=False)
    audit = [{'reason':name,'country_weeks':int(mask.sum()),'locations':int(w.loc[mask,'country'].nunique())} for name,mask in flags.items()]
    audit += [{'reason':'eligible_complete_week','country_weeks':int(w.complete.sum()),'locations':int(w.loc[w.complete,'country'].nunique())},
              {'reason':'eligible_positive_week','country_weeks':int(w.positive.sum()),'locations':int(w.loc[w.positive,'country'].nunique())},
              {'reason':'valid_zero_week','country_weeks':int(w.new_cases.eq(0).sum()),'locations':int(w.loc[w.new_cases.eq(0),'country'].nunique())}]
    pd.DataFrame(audit).to_csv(OUT/'weekly_exclusion_audit.csv',index=False)
    review.groupby('country').size().rename('daily_rows').to_csv(OUT/'locations_pending_review.csv')
    old = pd.read_csv(ROOT/'data/processed/exploration_2026-10-04/country_week_new_cases_exploration.csv',parse_dates=['week_start'])
    merged = old[['country','week_start','new_cases']].merge(w[['country','week_start','new_cases','exclusion_reasons']],on=['country','week_start'],suffixes=('_old','_validated'),validate='one_to_one')
    equal = merged.new_cases_old.eq(merged.new_cases_validated) | (merged.new_cases_old.isna() & merged.new_cases_validated.isna())
    merged.loc[~equal].to_csv(OUT/'weekly_changes_from_exploration.csv',index=False)
    assert hashlib.sha256(RAW.read_bytes()).hexdigest()==checksum
    meta = {'started_at':started,'finished_at':datetime.now(ZoneInfo('Europe/Berlin')).isoformat(),
            'raw_sha256':checksum,'raw_rows':len(raw),'provisional_daily_rows':len(d),
            'locations_pending_review':int(review.country.nunique()),'weekly_rows':len(w),
            'changed_weekly_targets':int((~equal).sum()),'imputation':'none',
            'partition':'continent-present locations; missing-continent locations retained for review',
            'reason_counts_overlap':True,'year_convention':'year of Monday week_start'}
    (OUT/'weekly_validation_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(pd.DataFrame(audit).to_string(index=False))
    print(json.dumps(meta,indent=2))
    return w

if __name__=='__main__':
    build()
