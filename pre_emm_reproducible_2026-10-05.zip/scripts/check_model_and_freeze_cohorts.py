"""Verify model edge cases and export fixed comparison cohorts."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json
import pandas as pd
from scripts.run_pre_emm_experiment import distribution, tv_distance

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data/processed/pre_emm_2026-10-05'

def check_and_freeze():
    started=datetime.now(ZoneInfo('Europe/Berlin')).isoformat()
    checks=[]
    def verify(name, condition):
        assert condition, name
        checks.append({'check':name,'passed':True})
    p=distribution(pd.Series(['1','1','2',None]),1)
    verify('known probabilities: 1=2/3, 2=1/3',abs(p['1']-2/3)<1e-12 and abs(p['2']-1/3)<1e-12)
    verify('probability sum = 1',abs(p.sum()-1)<1e-12)
    verify('identical distributions have TV = 0',tv_distance(p,p)==0)
    q=distribution(pd.Series(['9','9']),1)
    verify('disjoint distributions have TV = 1',abs(tv_distance(p,q)-1)<1e-12)
    verify('TV symmetry',abs(tv_distance(p,q)-tv_distance(q,p))<1e-12)
    two=distribution(pd.Series(['7','12','123',None]),2)
    verify('K=2 excludes one-digit values, no padding',two['12']==1 and len(two)==90)
    for name, values,k in [('empty group',[],1),('insufficient length',['7'],2),('invalid zero',['0'],1),('invalid K',['1'],0)]:
        caught=False
        try: distribution(pd.Series(values,dtype='object'),k)
        except ValueError: caught=True
        verify(name+' raises explicit error',caught)
    pd.DataFrame(checks).to_csv(OUT/'model_checks.csv',index=False)
    w=pd.read_csv(OUT/'validated_country_week.csv',dtype={'first_digit':'string','first_2_digits':'string','first_3_digits':'string'})
    core=['population','median_age','life_expectancy','population_density']
    summary=[]
    for k,field in [(1,'first_digit'),(2,'first_2_digits')]:
        for label, columns in [('target_only',[]),('core_complete',core),('core_gdp_complete',core+['gdp_per_capita'])]:
            mask=w[field].notna() & w[columns].notna().all(axis=1)
            cohort=w.loc[mask].copy()
            filename=f'cohort_k{k}_{label}.csv'
            cohort.to_csv(OUT/filename,index=False)
            verify(filename+' has unique country-week keys',not cohort.duplicated(['country','week_start']).any())
            summary.append({'cohort':label,'K':k,'rows':len(cohort),'locations':cohort.country.nunique(),'filename':filename})
    pd.DataFrame(checks).to_csv(OUT/'model_checks.csv',index=False)
    pd.DataFrame(summary).to_csv(OUT/'fixed_cohort_summary.csv',index=False)
    meta={'started_at':started,'finished_at':datetime.now(ZoneInfo('Europe/Berlin')).isoformat(),'checks_passed':len(checks),
          'recommended_main':'cohort_k1_core_complete.csv','secondary':'cohort_k2_core_complete.csv',
          'sensitivity':'target_only and core_gdp_complete cohorts',
          'caveat':'K cohorts differ; compare quality measures within a fixed cohort. Locations/country-weeks are not independent subjects.'}
    (OUT/'model_cohort_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(meta,indent=2))
    return pd.DataFrame(checks),pd.DataFrame(summary)

if __name__=='__main__': check_and_freeze()
