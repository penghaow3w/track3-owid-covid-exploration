"""Score predefined single-condition rules and inspect support sensitivity."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json
import pandas as pd
from scripts.run_pre_emm_experiment import distribution
from scripts.compare_quality_measures import distances

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data/processed/pre_emm_2026-10-05'
MEASURES=['TV','JS_divergence_bits','Hellinger']

def score_rules():
    started=datetime.now(ZoneInfo('Europe/Berlin')).isoformat()
    rows=[]
    for k,field in [(1,'first_digit'),(2,'first_2_digits')]:
        d=pd.read_csv(OUT/f'cohort_k{k}_core_binned.csv',dtype={field:'string'})
        rules={f'continent={v}':d.continent.eq(v) for v in sorted(d.continent.unique())}
        rules.update({f'year={v}':d.year.eq(v) for v in sorted(d.year.unique())})
        for c in ['population','median_age','life_expectancy','population_density']:
            rules.update({f'{c}:{v}':d[c+'_bin'].eq(v) for v in ['Q1','Q2','Q3','Q4']})
        for name,mask in rules.items():
            if not mask.any() or mask.all():
                continue
            p=distribution(d.loc[mask,field],k)
            q=distribution(d.loc[~mask,field],k)
            rows.append({'K':k,'rule':name,'cohort_rows':len(d),'subgroup_weeks':int(mask.sum()),
                'complement_weeks':int((~mask).sum()),'subgroup_locations':d.loc[mask,'country'].nunique(),
                'complement_locations':d.loc[~mask,'country'].nunique(),**distances(p,q)})
    scored=pd.DataFrame(rows)
    assert len(scored)==58
    for measure in MEASURES:
        scored[measure+'_rank']=scored.groupby('K')[measure].rank(ascending=False,method='min').astype(int)
    scored.to_csv(OUT/'prepared_rule_scores.csv',index=False)
    policies={'relaxed':(50,5),'baseline':(100,10),'strict':(500,30)}
    retained=[]; top=[]
    for k in (1,2):
        subset=scored.loc[scored.K.eq(k)]
        for policy,(weeks,locations) in policies.items():
            eligible=subset.loc[(subset.subgroup_weeks>=weeks)&(subset.complement_weeks>=weeks)&
                (subset.subgroup_locations>=locations)&(subset.complement_locations>=locations)]
            retained.append({'K':k,'policy':policy,'minimum_weeks_each':weeks,
                'minimum_locations_each':locations,'rules_retained':len(eligible),'rules_excluded':len(subset)-len(eligible)})
            for measure in MEASURES:
                for rank,(_,row) in enumerate(eligible.sort_values([measure,'rule'],ascending=[False,True]).head(5).iterrows(),1):
                    top.append({'K':k,'policy':policy,'measure':measure,'rank':rank,'rule':row.rule,'score':row[measure]})
    sensitivity=pd.DataFrame(retained)
    top=pd.DataFrame(top)
    sensitivity.to_csv(OUT/'support_policy_summary.csv',index=False)
    top.to_csv(OUT/'support_policy_top5.csv',index=False)
    meta={'started_at':started,'finished_at':datetime.now(ZoneInfo('Europe/Berlin')).isoformat(),
        'rules_per_K':29,'policies':policies,'search':'predeclared single-condition rules only',
        'limitations':'Threshold sensitivity is descriptive; does not establish significance or correct country/time dependence. No EMM search or rule conjunctions.'}
    (OUT/'prepared_rule_score_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(meta,indent=2))
    return scored,sensitivity,top

if __name__=='__main__': score_rules()
