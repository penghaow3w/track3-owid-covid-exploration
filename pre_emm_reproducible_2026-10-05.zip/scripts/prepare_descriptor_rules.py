"""Prepare fixed country-based bins and inspect subgroup support."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'data/processed/pre_emm_2026-10-05'
NUMERIC=['population','median_age','life_expectancy','population_density']

def prepare():
    started=datetime.now(ZoneInfo('Europe/Berlin')).isoformat()
    base=pd.read_csv(OUT/'cohort_k1_core_complete.csv')
    # Require a single observed value per country before country-based bins.
    variation=base.groupby('country')[NUMERIC].nunique()
    assert variation.le(1).all().all(), 'Time-varying descriptors need a reference-date policy'
    country=base.groupby('country')[NUMERIC].first()
    thresholds=[]
    for c in NUMERIC:
        for quantile,value in country[c].quantile([.25,.5,.75]).items():
            thresholds.append({'descriptor':c,'quantile':quantile,'threshold':value,
                'reference_locations':len(country),'reference':'K1 core-complete countries, one value per country'})
    cuts=pd.DataFrame(thresholds)
    cuts.to_csv(OUT/'descriptor_bin_thresholds.csv',index=False)
    support=[]
    for k in (1,2):
        d=pd.read_csv(OUT/f'cohort_k{k}_core_complete.csv')
        rules={f'continent={v}':d.continent.eq(v) for v in sorted(d.continent.unique())}
        rules.update({f'year={v}':d.year.eq(v) for v in sorted(d.year.unique())})
        for c in NUMERIC:
            q=cuts.loc[cuts.descriptor.eq(c)].set_index('quantile').threshold
            rules[f'{c}:Q1']=d[c].le(q.loc[.25])
            rules[f'{c}:Q2']=d[c].gt(q.loc[.25]) & d[c].le(q.loc[.5])
            rules[f'{c}:Q3']=d[c].gt(q.loc[.5]) & d[c].le(q.loc[.75])
            rules[f'{c}:Q4']=d[c].gt(q.loc[.75])
            labels=pd.Series(index=d.index,dtype='string')
            for label in ('Q1','Q2','Q3','Q4'):
                labels.loc[rules[f'{c}:{label}']]=label
            assert labels.notna().all()
            d[c+'_bin']=labels
        d.to_csv(OUT/f'cohort_k{k}_core_binned.csv',index=False)
        for name,mask in rules.items():
            n=int(mask.sum()); n_other=len(d)-n
            countries=int(d.loc[mask,'country'].nunique())
            other_countries=int(d.loc[~mask,'country'].nunique())
            support.append({'K':k,'rule':name,'subgroup_weeks':n,'complement_weeks':n_other,
                'subgroup_locations':countries,'complement_locations':other_countries,
                'support_fraction':n/len(d),'candidate_minimum_pass':n>=100 and n_other>=100 and countries>=10 and other_countries>=10})
    table=pd.DataFrame(support)
    table.to_csv(OUT/'candidate_rule_support.csv',index=False)
    meta={'started_at':started,'finished_at':datetime.now(ZoneInfo('Europe/Berlin')).isoformat(),
        'threshold_reference':'one value per country in K1 core-complete cohort; shared by K1/K2',
        'intervals':'Q1 <= p25; Q2 (p25,p50]; Q3 (p50,p75]; Q4 > p75; ties may produce unequal sizes',
        'candidate_filter':{'min_subgroup_weeks':100,'min_complement_weeks':100,'min_subgroup_locations':10,'min_complement_locations':10},
        'filter_status':'engineering screening choice, not a statistical guarantee; check threshold sensitivity later',
        'dependence':'Weeks are correlated within countries; unique-country count is coverage, not an independent sample size.',
        'rule_count':len(table),'passing_rules':int(table.candidate_minimum_pass.sum())}
    (OUT/'descriptor_rule_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(meta,indent=2))
    return cuts,table

if __name__=='__main__': prepare()
